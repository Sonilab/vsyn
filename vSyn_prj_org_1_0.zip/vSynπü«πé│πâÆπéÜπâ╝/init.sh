echo "# vSyn" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/sonir/vSyn.git
git push -u origin master
